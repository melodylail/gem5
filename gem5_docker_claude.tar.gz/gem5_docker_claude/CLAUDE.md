# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Purpose

Docker-based compilation environment for the [gem5 simulator](https://www.gem5.org). Provides a reproducible Ubuntu 24.04 container with all build dependencies pre-installed.

## Build the Image

```bash
docker build -t gem5-build:ubuntu-24.04 .
# or
docker compose build
```

## Use the Image

The container expects gem5 source mounted at `/gem5`. The entrypoint creates a non-root user matching your host UID/GID so build artifacts have correct ownership.

```bash
# Clone gem5 first
git clone https://github.com/gem5/gem5 gem5-src

# Build via docker compose (mounts ./gem5-src:/gem5 + ccache volume)
docker compose run --rm gem5 scons build/X86/gem5.opt -j$(nproc)

# Or raw docker
docker run --rm -it \
    -v $(pwd)/gem5-src:/gem5 \
    -e HOST_UID=$(id -u) -e HOST_GID=$(id -g) \
    gem5-build:ubuntu-24.04 \
    scons build/X86/gem5.opt -j$(nproc)
```

## gem5 Build Commands

ISA targets: `X86`, `ARM`, `RISCV`, `MIPS`, `POWER`, `SPARC`. Variants: `debug`, `opt`, `fast`.

```bash
scons build/X86/gem5.opt -j$(nproc)    # X86 optimized (recommended)
scons build/RISCV/gem5.opt -j$(nproc)   # RISC-V
scons build/ARM/gem5.opt -j$(nproc)     # ARM
scons build/ALL/gem5.opt -j$(nproc)     # All ISAs (slow)
```

`opt` includes debug symbols and assertions — best default. Use `fast` for benchmarks.

## Architecture

```
Dockerfile          → Ubuntu 24.04 image with all gem5 deps in a single layer
entrypoint.sh       → UID/GID user mapping, ccache setup, help banner
docker-compose.yml  → Convenience: mounts gem5-src:/gem5, named ccache volume
.dockerignore       → Excludes .omc/, gem5-src/, .ccache/ from build context
```

- All `apt install` and cleanup in one `RUN` to keep layers small.
- gem5 source is volume-mounted at runtime — the image is a pure build environment.
- ccache persisted via Docker named volume to speed up incremental builds.
- `XDG_CACHE_HOME=/tmp/` avoids pre-commit cache permission issues.
