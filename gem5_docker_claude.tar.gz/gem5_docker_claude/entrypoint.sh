#!/bin/bash
set -e

HOST_UID=${HOST_UID:-1000}
HOST_GID=${HOST_GID:-1000}
HOST_USER=${HOST_USER:-gem5}

# Create non-root user matching host UID/GID
if ! id -u "$HOST_USER" &>/dev/null; then
    groupadd -g "$HOST_GID" "$HOST_USER"
    useradd -u "$HOST_UID" -g "$HOST_GID" -m -s /bin/bash "$HOST_USER"
    echo "$HOST_USER ALL=(ALL) NOPASSWD:ALL" > /etc/sudoers.d/$HOST_USER
fi

mkdir -p /ccache && chown -R "$HOST_USER:$HOST_USER" /ccache

echo "=== gem5 Build Environment ==="
echo "Targets: X86 ARM RISCV MIPS POWER SPARC"
echo "Variants: debug / opt / fast"
echo ""
echo "  scons build/X86/gem5.opt -j\$(nproc)"
echo "  scons build/RISCV/gem5.opt -j\$(nproc)"
echo "  scons build/ALL/gem5.opt -j\$(nproc)"
echo ""

if [ $# -eq 0 ]; then
    exec su - "$HOST_USER"
else
    exec su - "$HOST_USER" -c "cd /gem5 && exec $*"
fi
